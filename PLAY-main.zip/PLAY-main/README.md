# control:
a - left
d- right
w - forward
s - forward
e - cursor up
r- cursor down
c - clear all
